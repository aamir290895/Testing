package com.java.developer;

public class Bank {
	
	public static SavingsAccount getAccount(String str) {
		if(str.equalsIgnoreCase("sav")) {
			return new SavingsAccount(101,"jack",5000);
		}else if(str.equalsIgnoreCase("sav2")){
			
			return new SavingsAccount(102,"harry",1000);
		}
		else {
			return null;
		}
	}
      
}
