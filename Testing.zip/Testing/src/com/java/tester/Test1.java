package com.java.tester;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.developer.Bank;
import com.java.developer.SavingsAccount;

public class Test1 {
	SavingsAccount acc;

	@Test
	public void TestA() {
		acc= Bank.getAccount("sav");
		
		Assertions.assertTrue(acc !=null);
		System.out.println("Test A passed");
		
	}
	@Test
	public void TestB() {
		acc = Bank.getAccount("sav2");
		acc.withdraw(1500);

		Assertions.assertEquals(1000, acc.getAccountBalance());
		System.out.println("Test B passed");
		
		
	}

}
